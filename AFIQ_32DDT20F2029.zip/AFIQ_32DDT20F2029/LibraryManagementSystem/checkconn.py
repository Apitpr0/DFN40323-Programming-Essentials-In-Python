import mysql.connector 
lms=mysql.connector.connect(host="localhost",user="root",password="")
print(lms)